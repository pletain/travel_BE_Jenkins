package com.samsam.travel.travelcommerce;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TravelCommerceApplication {

	public static void main(String[] args) {
		SpringApplication.run(TravelCommerceApplication.class, args);
	}

}
