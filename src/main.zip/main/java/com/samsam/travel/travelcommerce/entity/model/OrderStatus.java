package com.samsam.travel.travelcommerce.entity.model;
public enum OrderStatus {
    C, // Complete
    P // Pending
}