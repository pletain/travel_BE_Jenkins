package com.samsam.travel.travelcommerce.entity.model;

public enum Role {
    NORMAL,
    ADMIN,
    MASTER,
}
